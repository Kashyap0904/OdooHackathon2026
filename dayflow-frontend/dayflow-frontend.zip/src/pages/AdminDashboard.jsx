export default function AdminDashboard() {
  return (
    <div>
      <h2>Admin Dashboard</h2>

      <div>
        <button>Employees</button>
        <button>Attendance</button>
        <button>Leave Requests</button>
        <button>Payroll</button>
      </div>
    </div>
  );
}
