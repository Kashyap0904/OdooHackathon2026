export default function EmployeeDashboard() {
  return (
    <div>
      <h2>Employee Dashboard</h2>

      <div>
        <button>My Profile</button>
        <button>Attendance</button>
        <button>Apply Leave</button>
        <button>Salary</button>
      </div>
    </div>
  );
}
